import RobotTaskRenderer from './renderer';

export default {
  __init__: ['RobotTaskRenderer'],
  RobotTaskRenderer: ['type', RobotTaskRenderer],
};

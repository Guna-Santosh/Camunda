declare module 'diagram-js/lib/features/tooltips';
declare module 'diagram-js/lib/draw/BaseRenderer';

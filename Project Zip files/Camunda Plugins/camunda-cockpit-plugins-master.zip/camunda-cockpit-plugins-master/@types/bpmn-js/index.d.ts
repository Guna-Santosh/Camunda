declare module 'bpmn-js';
declare module 'bpmn-js/lib/NavigatedViewer';
declare module 'bpmn-js/lib/util/ModelUtil';
declare module 'bpmn-js/lib/features/modeling';

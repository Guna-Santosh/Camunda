declare module 'camunda-bpmn-js-behaviors';
declare module 'camunda-bpmn-js-behaviors/lib/camunda-platform';

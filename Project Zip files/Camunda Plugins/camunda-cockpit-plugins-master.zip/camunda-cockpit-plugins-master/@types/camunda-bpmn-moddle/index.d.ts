declare module 'camunda-bpmn-moddle';
declare module 'camunda-bpmn-moddle/resources';

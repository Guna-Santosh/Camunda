declare module 'svg-curves';

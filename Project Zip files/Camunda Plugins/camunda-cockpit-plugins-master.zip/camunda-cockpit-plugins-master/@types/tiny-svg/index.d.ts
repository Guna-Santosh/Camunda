declare module 'tiny-svg';

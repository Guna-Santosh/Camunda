* Dirk Budke (dbudke)
* Asko Soukka (datakurre)
